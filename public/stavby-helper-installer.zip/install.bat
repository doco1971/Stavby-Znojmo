@echo off
setlocal
title Stavby Helper - Instalace

if not exist "C:\Stavby" mkdir "C:\Stavby"

echo Kopiruju helper...
copy /Y "%~dp0stavby-helper.ps1" "C:\Stavby\stavby-helper.ps1" >nul

echo Vytvarim autostart...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut($env:APPDATA+'\Microsoft\Windows\Start Menu\Programs\Startup\StavbyHelper.lnk');$s.TargetPath='powershell.exe';$s.Arguments='-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File C:\Stavby\stavby-helper.ps1';$s.Save()"

echo Spoustim helper...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -ArgumentList '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File C:\Stavby\stavby-helper.ps1' -WindowStyle Hidden"

echo.
echo Hotovo! Helper bezi na pozadi.
echo Spousti se automaticky po prihlaseni do Windows.
echo.
pause
