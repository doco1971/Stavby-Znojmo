@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\StavbyHelper.lnk" >nul 2>&1
taskkill /F /IM powershell.exe /FI "WINDOWTITLE eq Stavby Helper*" >nul 2>&1
echo Odinstalace dokoncena.
pause
