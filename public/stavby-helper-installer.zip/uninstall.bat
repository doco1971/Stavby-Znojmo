@echo off
taskkill /F /FI "WINDOWTITLE eq Stavby Helper*" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 47891 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\StavbyHelper.lnk" >nul 2>&1
echo Odinstalace dokoncena.
pause
