# stavby-helper.ps1
Add-Type -AssemblyName System.Web

$port = 47891

# Ukonci starou instanci na portu
$existing = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if ($existing) {
    $oldPid = ($existing | Select-Object -First 1).OwningProcess
    $myPid = [System.Diagnostics.Process]::GetCurrentProcess().Id
    if ($oldPid -and $oldPid -ne $myPid) {
        Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    }
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
} catch {
    Write-Host "CHYBA: Port $port je stale obsazen. Restartujte PC."
    Start-Sleep 5
    exit 1
}

Write-Host "Stavby Helper bezi na http://localhost:$port"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $response.Headers.Add("Access-Control-Allow-Origin", "*")
        $response.Headers.Add("Access-Control-Allow-Methods", "GET, OPTIONS")

        $urlPath = $request.Url.AbsolutePath
        $fullUrl = $request.Url.ToString()
        Write-Host "Pozadavek: $fullUrl"

        if ($urlPath -eq "/ping") {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } elseif ($urlPath -eq "/open") {
            $query = [System.Web.HttpUtility]::ParseQueryString($request.Url.Query)
            $folderPath = $query["path"]
            Write-Host "Cesta: '$folderPath'"

            if ($folderPath) {
                Write-Host "Spoustim explorer: $folderPath"
                Start-Process 'explorer.exe' -ArgumentList ("`"" + $folderPath + "`"")
                $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
                $response.StatusCode = 200
            } else {
                Write-Host "CHYBA: prazdna cesta"
                $buffer = [System.Text.Encoding]::UTF8.GetBytes("ERROR: prazdna cesta")
                $response.StatusCode = 400
            }
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } else {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("Stavby Helper OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.OutputStream.Close()

    } catch {}
}
