# stavby-helper.ps1
# Stavby Znojmo - lokalni HTTP helper pro otevirani slozek
# Bezi na pozadi na http://localhost:47891
# Autostart: %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\StavbyHelper.lnk

Add-Type -AssemblyName System.Web

$port = 47891

# Ukonci starou instanci pokud bezi
$existing = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if ($existing) {
    $oldPid = ($existing | Select-Object -First 1).OwningProcess
    $myPid = [System.Diagnostics.Process]::GetCurrentProcess().Id
    if ($oldPid -and $oldPid -ne $myPid) {
        Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    }
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
} catch {
    exit 1
}

# Windows API pro SetForegroundWindow
$sig = @"
[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);
"@
$winAPI = Add-Type -MemberDefinition $sig -Name WinAPI -Namespace WinAPI -PassThru -ErrorAction SilentlyContinue

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $response.Headers.Add("Access-Control-Allow-Origin", "*")
        $response.Headers.Add("Access-Control-Allow-Methods", "GET, OPTIONS")

        $urlPath = $request.Url.AbsolutePath

        if ($urlPath -eq "/ping") {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } elseif ($urlPath -eq "/open") {
            $query = [System.Web.HttpUtility]::ParseQueryString($request.Url.Query)
            $folderPath = $query["path"]

            if ($folderPath) {
                # Otevri slozku
                $arg = "/root,`"" + $folderPath + "`""
                Start-Process 'explorer.exe' -ArgumentList $arg
                Start-Sleep -Milliseconds 800

                # Dej okno na popredi
                $explorerProc = Get-Process explorer -ErrorAction SilentlyContinue |
                    Where-Object { $_.MainWindowHandle -ne 0 } |
                    Select-Object -Last 1
                if ($explorerProc -and $winAPI) {
                    $hwnd = $explorerProc.MainWindowHandle
                    $winAPI::ShowWindowAsync($hwnd, 9) | Out-Null
                    $winAPI::SetForegroundWindow($hwnd) | Out-Null
                }

                $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
                $response.StatusCode = 200
            } else {
                $buffer = [System.Text.Encoding]::UTF8.GetBytes("ERROR: prazdna cesta")
                $response.StatusCode = 400
            }
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } else {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.OutputStream.Close()

    } catch {}
}
